#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"

void TIM9_CH1_Cap_Init(u32 arr,u16 psc);

#endif























