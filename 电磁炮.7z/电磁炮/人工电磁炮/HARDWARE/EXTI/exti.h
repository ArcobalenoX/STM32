#ifndef __EXTI_H
#define __EXTI_H
#include "sys.h"
#include "delay.h"
#include "key.h"

extern u8 PWM1,PWM2;
void EXTIX_Init(void);	//�ⲿ�жϳ�ʼ��
#endif

























