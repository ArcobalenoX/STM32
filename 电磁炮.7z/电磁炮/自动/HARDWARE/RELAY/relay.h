#ifndef __RELAY_H
#define __RELAY_H
#include "sys.h"

void RELAY_ON(void);
void RELAY_OFF(void);
void RELAY_Init(void);
void OPENMV_Init(void);

#endif
