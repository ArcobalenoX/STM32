#ifndef __FUN_H
#define __FUN_H
#include "sys.h"

u8 switch_key(u8 key);



#endif
